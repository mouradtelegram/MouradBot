# MouradBot
Telegram-bot med Stripe-betaling, poengsystem og verving.